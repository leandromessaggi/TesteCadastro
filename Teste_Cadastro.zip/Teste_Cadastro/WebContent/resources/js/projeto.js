function salvar(valor){
		
		var contexto = $('#contexto').val();
		
		if(valor != null){
			
			$.ajax({
				type: 'GET',
				url: contexto + '/salvar',
				data: 'valor=' + valor,
				cache: false,
				async: false,
				traditional: true,
				success: function(result) {
					if(result != null && result != undefined && result != ''){
						alert('Salvo!');
					}else{
						alert('Erro.');
						
					}
				}
				
			});
			
		}
		
	}