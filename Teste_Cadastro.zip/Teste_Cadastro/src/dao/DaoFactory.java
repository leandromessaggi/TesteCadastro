package dao;

import model.Cadastro;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class DaoFactory {

	private static final SessionFactory sessionFactory = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();

	private static Dao<Cadastro> cadastroDao;
               
	public static SessionFactory recuperaSession(){
		return sessionFactory;
	}

	public static Dao<Cadastro> getCadastroDao(){
		if(cadastroDao == null ){
			cadastroDao = new Dao<Cadastro>(Cadastro.class, recuperaSession()); 
		}
		return cadastroDao;
	}

}