package dao;

import java.sql.Connection;
import java.util.List;

import org.hibernate.CacheMode;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import util.GenericUtil;
import util.StringUtil;

public class Dao<T> {

	@SuppressWarnings("rawtypes")
	private Class classe;   
    private Session session;   
    private SessionFactory sessionFactory;
    private Transaction transaction;
    
    @SuppressWarnings("rawtypes")
    public Dao(Class classe, SessionFactory sessionFactory){   
        this.classe = classe;
        if(sessionFactory == null){
        	/* Metodo que cria a sessionFactory */
        	sessionFactory = DaoFactory.recuperaSession();
        }
        if(this.sessionFactory == null){
        	this.sessionFactory = sessionFactory;
        }
        getSession();
    }  
    
    public boolean inserir(T t){  
    	try{
    		this.transaction = getSession().beginTransaction();
    		this.session.save(t);
    		this.transaction.commit();
    		this.session.close();
    		return true;
    	}catch (Exception e) {
    		e.printStackTrace();
    		this.transaction.rollback();
    		this.session.close();
    		return false;
		}
    }   
       
    public boolean deletar(T t){
    	try{
    		this.transaction = getSession().beginTransaction();
    		this.session.delete(t);   
    		this.transaction.commit();
    		closeConnection();
    		return true;
    	}catch (Exception e) {
    		e.printStackTrace();
    		this.transaction.rollback();
    		closeConnection();
    		return false;
		}
    }   
       
    public boolean atualizar(T t){ 
    	try{
    		this.transaction = getSession().beginTransaction();
    		this.session.update(t);   
    		this.transaction.commit();
    		closeConnection();
    		return true;
    	}catch (Exception e) {
    		e.printStackTrace();
    		this.transaction.rollback();
    		closeConnection();
    		return false;
		}
    }   
    
    public boolean merge(T t){ 
    	try{
    		this.transaction = getSession().beginTransaction();
    		this.session.merge(t);   
    		this.transaction.commit();
    		closeConnection();
    		return true;
    	}catch (Exception e) {
    		e.printStackTrace();
    		this.transaction.rollback();
    		closeConnection();
    		return false;
		}
    } 
       
    @SuppressWarnings({"unchecked"})
	public List<T> listaTudo(boolean ativo){  
    	List<T> ret = null;
    	getSession().beginTransaction();
        Criteria criteria = criaCriteria(); 
        criteria.add(Restrictions.eq("ativo", ativo));
        ret = criteria.list();
        closeConnection();
        return ret;
    }

    @SuppressWarnings({"unchecked"})
	public List<T> listaTudo(boolean ativo, boolean asc, String ordernaPor){  
    	List<T> ret = null;
    	getSession().beginTransaction();
        Criteria criteria = criaCriteria();
        criteria.add(Restrictions.eq("ativo", ativo));
        
        if(asc){
        	criteria.addOrder(Order.asc(ordernaPor));
        }else{
        	criteria.addOrder(Order.desc(ordernaPor));
        }
        
        ret = criteria.list();
        closeConnection();
        return ret;
    }
    
    @SuppressWarnings({"unchecked"})
	public List<T> listaPorParametro(String parametro, Object valor){  
    	List<T> ret = null;
    	getSession().beginTransaction();
        Criteria criteria = criaCriteria();
        criteria.add(Restrictions.eq(parametro, valor));
        ret = criteria.list();
        closeConnection();
        return ret;
    }
    
    @SuppressWarnings({"unchecked"})
	public T buscaPorParametro(String parametro, Object valor){  
    	T ret = null;
    	getSession().beginTransaction();
        Criteria criteria = criaCriteria();
        criteria.add(Restrictions.eq(parametro, valor));
        ret = (T) criteria.uniqueResult();
        closeConnection();
        return ret;
    }
    
    @SuppressWarnings({"unchecked"})
	public T buscaPorParametro(String parametro, String valor){  
    	T ret = null;
    	getSession().beginTransaction();
        Criteria criteria = criaCriteria();
        criteria.add(Restrictions.eq(parametro, valor));
        ret = (T) criteria.uniqueResult();
        closeConnection();
        return ret;
    }
    
    @SuppressWarnings({"unchecked"})
	public List<T> listaTudo(boolean asc, String ordernaPor){ 
    	List<T> ret = null;
    	getSession().beginTransaction();
        Criteria criteria = criaCriteria();
        
        if(asc){
        	criteria.addOrder(Order.asc(ordernaPor));
        }else{
        	criteria.addOrder(Order.desc(ordernaPor));
        }
        
        ret = criteria.list();
        closeConnection();
        return ret; 
    }  
    
    @SuppressWarnings({"unchecked"})
	public List<T> listaTudo(){ 
    	List<T> ret = null;
    	getSession().beginTransaction();
        Criteria criteria = criaCriteria();       
        ret = criteria.list();
        closeConnection();
        return ret; 
    }
    
    @SuppressWarnings({"unchecked"})
	public List<T> listaTodosId(){
    	List<T> ret = null;
    	getSession().beginTransaction();
    	Criteria criteria = criaCriteria();
    	criteria.setProjection(Projections.property("id"));
        ret = criteria.list();
        closeConnection();
        return ret;
    }
    
    @SuppressWarnings("unchecked")
	public T buscaPorId(long id){
    	T ret = null;
    	getSession().beginTransaction();
    	Criteria criteria = criaCriteria();
    	criteria.add(Restrictions.eq("id", id));
    	ret = (T) criteria.uniqueResult();
    	closeConnection();
    	return ret;
    }
    
    @SuppressWarnings("unchecked")
	public List<T> pesquisaPorId(Object[] ids){
    	List<T> ret = null;
    	getSession().beginTransaction();
    	Criteria criteria = criaCriteria();
    	criteria.add(Restrictions.in("id", ids));
    	ret = criteria.list();
    	closeConnection();
    	return ret;
    }
    
    @SuppressWarnings("unchecked")
	public T buscaPorDescricao(String descricao){
    	T ret = null;
    	getSession().beginTransaction();
    	Criteria criteria = criaCriteria();
    	criteria.add(Restrictions.like("descricao", descricao.toLowerCase(),MatchMode.ANYWHERE));
    	ret = (T) criteria.uniqueResult();
    	closeConnection();
    	return ret;
    }
    
	@SuppressWarnings("unchecked")
	public List<T> buscaPorDescricaoEStatus(Object objeto){
		List<T> ret = null;
		getSession();
		Criteria criteria = getSession().createCriteria(objeto.getClass());
		if(!StringUtil.eNullouVazio((String) GenericUtil.get(objeto, "descricao"))){
			criteria.add(Restrictions.like("descricao", ( (String) GenericUtil.get(objeto, "descricao")).toLowerCase(),MatchMode.ANYWHERE));
		}
		criteria.add(Restrictions.eq("ativo", GenericUtil.get(objeto, "ativo")));
        ret = criteria.list();
        closeConnection();
        return ret; 
	}
	
	@SuppressWarnings("unchecked")
	public List<T> listaPorIdEmIntervalo(long idInicial, long idFinal){
		List<T> ret = null;
		getSession();
		Criteria criteria = criaCriteria();
		criteria.add(Restrictions.ge("id", idInicial));
		criteria.add(Restrictions.le("id", idFinal));
        ret = criteria.list();
        closeConnection();
        return ret; 
	}

	
	@SuppressWarnings("unchecked")
	public T buscaPorUltimoIdCadastrado(){
    	T ret = null;
    	getSession().beginTransaction();
    	Criteria criteria = criaCriteria();
    	criteria.setMaxResults(1);
    	criteria.addOrder(Order.desc("id"));
    	ret = (T) criteria.uniqueResult();
    	closeConnection();
    	return ret;
    }
	
	@SuppressWarnings("unchecked")
	public T carrega(Object objeto){
    	T ret = null;
    	getSession();
		Criteria criteria = getSession().createCriteria(objeto.getClass());
		if(!StringUtil.eNullouVazio((String) GenericUtil.get(objeto, "descricao"))){
			criteria.add(Restrictions.ilike("descricao", ((String) GenericUtil.get(objeto, "descricao")).toLowerCase(),MatchMode.ANYWHERE));
		}
		criteria.add(Restrictions.eq("ativo", GenericUtil.get(objeto, "ativo")));
    	ret = (T) criteria.uniqueResult();
    	closeConnection();
    	return ret;
	}
	
	protected Session getSession(){
		if(this.session == null){
			this.session = this.sessionFactory.openSession();
		}else{
			if(!this.session.isOpen()){
				this.session = this.sessionFactory.openSession();
			}
		}
		
		this.session.setCacheMode(CacheMode.IGNORE);
		try{this.session.clear();}catch (Exception e){}
		
		return this.session;
	}
	
	public void closeConnection(){
		if(this.session != null && this.session.isOpen()){
			this.session.close();
		}
	}
	
	public Connection getConnection(){
		return getSession().connection();
	}
	
	public Criteria criaCriteria(){
		return getSession().createCriteria(this.classe);
	}
	
	@SuppressWarnings("rawtypes")
	public Criteria criaCriteria( Class classe){
		getSession();
		return getSession().createCriteria(classe);
	}
	
}  