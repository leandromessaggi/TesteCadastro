package model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.ForeignKey;

import fmk.model.ObjectUtil;

@Entity
@Table(name="Cadastro")
public class Cadastro extends ObjectUtil implements Serializable{

	private static final long serialVersionUID = 5278126963367503186L;

	@Id
	@Column(name="Id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="texto")	
	private String texto;
	
	@Column(name="check")
	private String check;
	
	@Column(name="cbox")
	private String cbox;
	
	@Column(name="radio")
	private String radio;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getTexto() {
		return texto;
	}
	public void setTexto(String S) {
		this.texto = S;
	}	
	
	public String getCheck() {
		return check;
	}
	public void setCheck(String S) {
		this.check = S;
	}
	
	public String getCbox() {
		return cbox;
	}
	public void setCbox(String S) {
		this.cbox = S;
	}	
	
	public String getRadio() {
		return radio;
	}
	public void setRadio(String S) {
		this.radio = S;
	}
}


