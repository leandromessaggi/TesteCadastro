package util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtil {
	
	public static Date sqlDateToDate(java.sql.Date date){
		return new Date(date.getTime());
	}
	
	public static java.sql.Date dateToSQLDate(Date date){
		return new java.sql.Date(date.getTime());
	}
	
	public static Calendar dateToCalendar(Date date){
		Calendar c = new GregorianCalendar();
		c.setTime(date);
		return c;
	}
	
	public static Date setTimeStamp(Date date){
		Calendar aux = new GregorianCalendar();
		aux.setTime(date);
		Calendar ret = new GregorianCalendar();
		ret.set(Calendar.DAY_OF_MONTH, aux.get(Calendar.DAY_OF_MONTH));
		ret.set(Calendar.MONTH, aux.get(Calendar.MONTH));
		ret.set(Calendar.YEAR, aux.get(Calendar.YEAR));
		return ret.getTime();
	}

	public static Date CalendarToUtilDate(Calendar calendar){
		return new Date(calendar.getTimeInMillis());
	}
	
	public static String dateToString(Date date, String format){
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}
	
	public static java.sql.Date CalendarToSQLDate(Calendar calendar){
		return new java.sql.Date(calendar.getTimeInMillis());
	}
	
	public static String calendarToSQLServerDate(Calendar calendar){
		StringBuilder ret = new StringBuilder();
		ret.append(calendar.get(Calendar.YEAR)).append("-").append(calendar.get(Calendar.MONTH) + 1).append("-").append(calendar.get(Calendar.DAY_OF_MONTH)).append(" ");
		ret.append(calendar.get(Calendar.HOUR_OF_DAY)).append(":").append(calendar.get(Calendar.MINUTE)).append(":").append(calendar.get(Calendar.SECOND)).append(":").append(calendar.get(Calendar.MILLISECOND));
		return ret.toString();
	}
	
	public static String dateToSQLServerDate(Date data){
		StringBuilder ret = new StringBuilder();
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(data);
		ret.append(calendar.get(Calendar.YEAR)).append("-").append(calendar.get(Calendar.MONTH) + 1).append("-").append(calendar.get(Calendar.DAY_OF_MONTH)).append(" ");
		ret.append(calendar.get(Calendar.HOUR_OF_DAY)).append(":").append(calendar.get(Calendar.MINUTE)).append(":").append(calendar.get(Calendar.SECOND)).append(":").append(calendar.get(Calendar.MILLISECOND));
		return ret.toString();
	}
	
	public static int diferencaEntreDatas(Date date1, Date date2){
		return (int) ( (date2.getTime() - date1.getTime() ) / (24 * 60 * 60 * 1000) );
	}
	
	public static Date parseToDate(String date, String format){
		Date ret; 
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		try {
			ret = sdf.parse(date);
		} catch (ParseException e) {
			ret = null;
		}
		return ret;
	}
	
	public static Date parseToDate(Date date, String format){
		Date ret = date; 
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		try {
			ret = sdf.parse(date.toString());
		} catch (ParseException e) {
			ret = date;
		}
		return ret;
	}
	
	public static Date millisToDate(long millis, String format) throws ParseException{
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(millis);			
		Date dataAux = c.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.parse(sdf.format(dataAux));
	}
	
	public static boolean dateBetween(Date date, Date dateStart, Date dateEnd){
		boolean ret = false;
		if(date.after(dateStart) && date.before(dateEnd)){
			ret = true;
		}
		return ret;
	}
	
	public static Date randomDate(String dateStart, String dateEnd) {
		Date ret = null;
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			int year = NumberUtil.aleatorioEntre(Integer.parseInt(dateStart.substring(6,10)), Integer.parseInt(dateEnd.substring(6,10)));
			int month = NumberUtil.aleatorioEntre(Integer.parseInt(dateStart.substring(3,5)), Integer.parseInt(dateEnd.substring(3,5)));
			int day = NumberUtil.aleatorioEntre(Integer.parseInt(dateStart.substring(0,2)), Integer.parseInt(dateEnd.substring(0,2)));		
			ret = sdf.parse(day + "/" + month + "/" + year);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return ret;
	}
	
	public static String millisToDateString(long millis, String format){
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(millis);			
		Date dataAux = c.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(dataAux);
	}
	
	public static Integer lastDayInMonth(){
		return new GregorianCalendar().getActualMaximum(Calendar.DAY_OF_MONTH);
	}

	public static Integer lastDayInMonth(Date date){
		Calendar c = new GregorianCalendar();
		c.setTime(date);
		return c.getMaximum(Calendar.DAY_OF_MONTH);
	}
	
	public static Integer lastDayInMonth(Calendar date){
		return date.getMaximum(Calendar.DAY_OF_MONTH);
	}
	
	public static Date endOfDay(Date date){
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 99);
		return calendar.getTime();
	}
	
	public static Date beginOfDay(Date date){
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}
	
	public static String diferencaEntreHorasString(String horaInicial, String horaFinal){
		
		StringBuffer ret = new StringBuffer();
		
		int hora = Integer.parseInt(horaInicial.substring(0,2));
		int min = Integer.parseInt(horaInicial.substring(3,5));
		
		Calendar c1 = Calendar.getInstance();
		c1.set(Calendar.HOUR, hora);
		c1.set(Calendar.MINUTE, min);
		c1.set(Calendar.SECOND, 0);
		
		hora = Integer.parseInt(horaFinal.substring(0,2));
		min = Integer.parseInt(horaFinal.substring(3,5));
		
		Calendar c2 = Calendar.getInstance();
		if(hora == 0){
			c2.set(Calendar.DAY_OF_MONTH, c2.get(Calendar.DAY_OF_MONTH) + 1);
		}
		
		c2.set(Calendar.HOUR, hora);
		c2.set(Calendar.MINUTE, min);
		c2.set(Calendar.SECOND, 0);
		
		long valor = (c2.getTimeInMillis() - c1.getTimeInMillis())/60000;
		
		if(valor >= 60){
			long h = valor / 60;
			long m = valor % 60;
			if(h < 10){
				ret.append("0").append(h);
			}else{
				ret.append(h);
			}
			ret.append(":");
			if(m < 10){
				ret.append("0").append(m);
			}else{
				ret.append(m);
			}
		}else{
			ret.append("00:");
			if(valor < 10){
				ret.append("0").append(valor);
			}else{
				ret.append(valor);
			}
		}
		return ret.toString();
	}
	
	public static String somaEntreHorasString(String horaInicial, String horaFinal){
		
		StringBuffer ret = new StringBuffer();
		
		if(horaInicial != null && horaFinal != null){
			
			if("".equals(horaInicial)){
				horaInicial = "00:00";
			}
			
			int hora1 = Integer.parseInt(horaInicial.substring(0,2));
			int min1 = Integer.parseInt(horaInicial.substring(3,5));
			
			int hora2 = Integer.parseInt(horaFinal.substring(0,2));
			int min2 = Integer.parseInt(horaFinal.substring(3,5));
			
			int h = hora2 + hora1;
			int m = min2 + min1;
			
			int min = m;
			if(m > 60){
				h = h + (m / 60);
				min = m % 60;
			}
			
			if(h < 10){
				ret.append("0").append(h);
			}else{
				ret.append(h);
			}
			
			ret.append(":");
			
			if(m < 10){
				ret.append("0").append(min);
			}else{
				ret.append(min);
			}

		}
		
		return ret.toString();
	}
	
	public static String mediaHoraString(String hora, int periodo){
		StringBuffer ret = new StringBuffer();
		
		int hr = Integer.parseInt(hora.substring(0,2));
		int min = Integer.parseInt(hora.substring(3,5));
		
		int hrMedia = hr / periodo;
		int minMedia = min / periodo;
		
		if(hrMedia < 10){
			ret.append("0").append(hrMedia);
		}else{
			ret.append(hrMedia);
		}
		
		ret.append(":");
		
		if(minMedia < 10){
			ret.append("0").append(minMedia);
		}else{
			ret.append(minMedia);
		}
	
		return ret.toString();
	}
	
	public static String diferencaEntreDataHoraString(String dataInicial, String dataFinal) throws ParseException{
	
		Calendar c1 = DateUtil.dateToCalendar(parseToDate(dataInicial, "dd/MM/yyyy HH:mm:ss"));
		Calendar c2 = DateUtil.dateToCalendar(parseToDate(dataFinal, "dd/MM/yyyy HH:mm:ss"));
		
		long valor = (c2.getTimeInMillis() - c1.getTimeInMillis())/60000;
		
		StringBuilder ret = new StringBuilder();
		if(valor >= 60){
			long h = valor / 60;
			long m = valor % 60;
			if(h < 10){
				ret.append("0").append(h);
			}else{
				ret.append(h);
			}
			ret.append(":");
			if(m < 10){
				ret.append("0").append(m);
			}else{
				ret.append(m);
			}
		}else{
			ret.append("00:");
			if(valor < 10){
				ret.append("0").append(valor);
			}else{
				ret.append(valor);
			}
		}
		return ret.toString();
	}
	
}