package util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;



public class ArchiveUtil {

	public static List<String> lerArquivo(String path){
		List<String> ret = null;
		
		try {
			
			if(!StringUtil.eNullouVazio(path)){
				File file = new File(path);
				FileReader fileReader = new FileReader(file);
				BufferedReader buffer = new BufferedReader(fileReader);
				String line = buffer.readLine();
				if(line != null){
					ret = new ArrayList<String>();
				}
				while(line != null){
					ret.add(line);
					line = buffer.readLine();
				}
				fileReader.close();
				buffer.close();
			}
			
		} catch (IOException e) {
		    e.printStackTrace();
		}
		return ret;
	}
	
	public static byte[] fileToByteArray(File file){
		byte[] ret = null;
	    if ( file != null ) {
		    ByteArrayOutputStream ous = null;
		    InputStream ios = null;
		    try {
		        byte[] buffer = new byte[4096];
		        ous = new ByteArrayOutputStream();
		        ios = new FileInputStream(file);
		        int read = 0;
		        while ( (read = ios.read(buffer)) != -1 ) {
		            ous.write(buffer, 0, read);
		        }
		    } catch (FileNotFoundException e) {}
		      catch (IOException e) {}
		    finally { 
		        try {
		             if (ous != null){
		            	 ous.close();
		             }
		             if (ios != null) {
		            	 ios.close();
		             }
		        } catch (IOException e) { }
		    }
		    ret = ous.toByteArray();
	    }
	    return ret;
	}
}