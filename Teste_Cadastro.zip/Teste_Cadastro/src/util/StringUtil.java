package util;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.List;
import java.util.UUID;

public class StringUtil {
	
	public static boolean eNullouVazio(String text){
		boolean ret = false;
		if(text == null || "".equals(text) || " ".equals(text))
			ret = true;
		return ret;
	}
	
	public static String removeUltimoCaracter(String text){
		return text.substring(0, (text.length() - 1));
	}
			
	public static boolean igual(String text, List<String> parameters, boolean equalsAll){
		boolean ret = false;
		if(parameters != null && parameters.size() > 0){
			if(equalsAll){
				int found = 0;
				for(int i = 0; i < parameters.size();i++){
					if(text.equals(parameters.get(i))){
						found++;
					}
				}
				if(found == (parameters.size())){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.size()){
					if(text.equals(parameters.get(i))){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	@SuppressWarnings("rawtypes")
	public static boolean contem(String text, List parameters, boolean containsAll){
		boolean ret = false;
		if(parameters != null && parameters.size() > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.size();i++){
					if(text.contains((CharSequence) parameters.get(i))){
						found++;
					}
				}
				if(found == (parameters.size())){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.size()){
					if(text.contains((CharSequence) parameters.get(i))){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	public static boolean igual(String text, String[] parameters, boolean equalsAll){
		boolean ret = false;
		if(parameters != null && parameters.length > 0){
			if(equalsAll){
				int found = 0;
				for(int i = 0; i < parameters.length;i++){
					if(text.equals(parameters[i])){
						found++;
					}
				}
				if(found == (parameters.length)){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.length){
					if(text.equals(parameters[i])){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	public static boolean contem(String text, String[] parameters, boolean containsAll){
		boolean ret = false;
		if(parameters != null && parameters.length > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.length;i++){
					if(text.contains(parameters[i])){
						found++;
					}
				}
				if(found == (parameters.length)){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.length){
					if(text.contains(parameters[i])){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	public static String criaMascara(String obj, int length, String character){
		int n = length - obj.length();
		String result = obj;
		if(n > 0){
			result = "";
			for(int i = 0; i < n; i++){
				result += character;
			}
			result += obj;			
		}
		return result;
	}
	
	public static String generateTokenUUID(){
		return UUID.randomUUID().toString();
	}
		
	public static boolean verifyTokenUUID(String uuid){
		boolean ret = false;
		try{
			String aux = UUID.fromString(uuid).toString();
			if(uuid.equals(aux)){
				ret = true;
			}else{
				ret = false;
			}			
		}catch (Exception e){
			ret = false;
		}
		return ret;
	}
	
	public static String puzzletext(String text, boolean specialChars){
		String ret = null;
		
		String[] alphabet = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n",
					"o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E",
					"F","G","H","J","I","J","K","L","M","N","O","P","Q","R","S","T","U","V",
					"W","X","Y","Z","0","1","2","3","4","5","6","7","8","9"};			
		
		String[] aux = null;
		if(specialChars){
			String[] specChars = {"!","@","#","$","%","&"};			
			aux = new String[alphabet.length + specChars.length];
			System.arraycopy(alphabet, 0, aux, 0, alphabet.length);
			System.arraycopy(specChars, 0, aux, alphabet.length, specChars.length);
		}else{
			aux = alphabet;
		}
		
		if(text != null && !text.equals("") && !text.equals(" ")){

			char[] chars = text.toCharArray();
			
			StringBuffer sb = new StringBuffer();
			
			for(char c : chars){
				int pos = NumberUtil.aleatorioEntre(0, aux.length - 1);
				sb.append(c).append(aux[pos]);
			}
			
			ret = sb.toString();
		}
		return ret;
	}
	
	public static String unPuzzleText(String text){
		String ret = null;
		
		if(text != null && !text.equals("") && !text.equals(" ")){
			char[] chars = text.toCharArray();
			
			StringBuffer sb = new StringBuffer();
			for(int i = 0; i < chars.length; i = i + 2){
				sb.append(chars[i]);
			}
			ret = sb.toString();
		}
		return ret;
	}
	
	public static String setOneSpace(String text){
		String ret = text;
		if(text != null && text.contains(" ")){
			ret = text.replaceAll("\\s+", " ").trim();
		}
		return ret;
	}
	
	public static String criptografiaMD5(String text){
		String ret = text;
		MessageDigest messageDigest = null;
		try {
			messageDigest = MessageDigest.getInstance("MD5");
			BigInteger hash = new BigInteger(1, messageDigest.digest(text.getBytes()));
			ret = hash.toString(23);
		} catch (Exception e) {}
		return ret;
	}
	
	public static String criptografiaSHA1(String text){
		String ret = text;
		MessageDigest messageDigest = null;
		try {
			messageDigest = MessageDigest.getInstance("SHA1");
			BigInteger hash = new BigInteger(1, messageDigest.digest(text.getBytes()));
			ret = hash.toString(23);
		} catch (Exception e) {}
		
		return ret;
	}
	
	public static String removeAcentos(String texto) {
		texto = Normalizer.normalize(texto, Normalizer.Form.NFD);
		texto = texto.replaceAll("[^\\p{ASCII}]", "");
		return texto;
	}

		
}