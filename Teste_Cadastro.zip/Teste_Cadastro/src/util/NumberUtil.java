package util;

import java.util.List;

public class NumberUtil {

	public static boolean isNull(Integer integer){
		boolean ret = false;
		
		if(integer == null){
			ret = true;
		}
		return ret;
	}
	
	public static boolean isNull(Long longN){
		boolean ret = false;
		
		if(longN == null){
			ret = true;
		}
		return ret;
	}
	
	public static boolean isNull(Double doub){
		boolean ret = false;
		
		if(doub == null){
			ret = true;
		}
		return ret;
	}
	
	public static boolean isNull(Float flt){
		boolean ret = false;
		
		if(flt == null){
			ret = true;
		}
		return ret;
	}
	
	public static Integer doubleToInteger(Double doub){
		Integer ret = 0;
		
		if(doub != null){
			ret = doub.intValue();
		}
		return ret;
	}
	
	public static Double integerToDouble(Integer integer){
		Double ret = 0.0;
		
		if(integer != null){
			ret = integer.doubleValue();
		}
		return ret;
	}
	
	public static String formatDoubleValue(Double value, int decimal){
		String formatedValue = "";
		
		if(value != null){
			formatedValue = String.valueOf(value).replace(".", ",");
			
			int decimalOnFormatedValue = (formatedValue.length() - formatedValue.indexOf(",")) -1 ;
			
			if(decimalOnFormatedValue != decimal){
				for (int i = decimalOnFormatedValue; i < decimal; i++){
					formatedValue = formatedValue + "0";
				}
			}else{
				formatedValue = formatedValue.substring(0,formatedValue.length() - (decimalOnFormatedValue - decimal));
			}
		}
		return formatedValue;
	}
	
	public static String addZeros(Integer number, int zeros){
		String ret = "";
		
		int zerosAdd = 0;
		if(number != null && number != 0){
			while(zerosAdd < zeros){
				ret += "0";
				zerosAdd++;
			}
			ret += number;			
		}
		
		if(ret == ""){
			ret = String.valueOf(number);
		}
		return ret;
	}
	
	public static Integer aleatorioEntre(Integer n1, Integer n2){
		Integer ret = 0;

		if(n1 != null && n2 != null){
			n2++;
			if(n1 >= n2){
				Integer aux = n1;
				n1 = n2;
				n2 = aux;
			}
			
			int a = 10;
			int i = n2 + 1;
			do{
				if(a < i){
					a = a * 10;				
				}
			}while(a < i);						
				
			Double d = 0.0;
			boolean stop = false;
			while(!stop){
				d = Math.random() * a;
				if(d >= n1 && d <= n2){
					stop = true;
				}
			}
			ret = d.intValue();
		}	
		return ret;
	}
	
	/**
	 * 
	 * @param n1
	 * @param scale Representa a pot�ncia de 10 da qual deseja o numero (ex. scale = 1 => retorno entre 0 e 10, scale = 2 => retorno entre 0 e 100
	 * @return
	 */
	public static Integer random(Integer scale){
		Integer ret = 0;
		
		int a = 10;
		for(int i = 1; i < scale; i++){
			a = a * 10;
		}
		
		Double d = Math.random() * a;
		
		ret = d.intValue();
		
		return ret;
	}
	
	public static String addZeros(Long number, int zeros){
		String ret = "";
		
		int zerosAdd = 0;
		if(number != null && number != 0){
			while(zerosAdd < zeros){
				ret += "0";
				zerosAdd++;
			}
			ret += number;			
		}
		
		if(ret == ""){
			ret = String.valueOf(number);
		}
		return ret;
	}
	
	public static boolean contem(Integer value, List<Integer> parameters, boolean containsAll){
		boolean ret = false;
		if(parameters != null && parameters.size() > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.size();i++){
					if(value.equals(parameters.get(i))){
						found++;
					}
				}
				if(found == (parameters.size())){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.size()){
					if(value.equals(parameters.get(i))){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	public static boolean contem(Integer value, Integer[] parameters, boolean containsAll){
		boolean ret = false;
		if(parameters != null && parameters.length > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.length;i++){
					if(value.equals(parameters[i])){
						found++;
					}
				}
				if(found == (parameters.length)){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.length){
					if(value.equals(parameters[i])){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	public static boolean contem(Double value, List<Double> parameters, boolean containsAll){
		boolean ret = false;
		if(parameters != null && parameters.size() > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.size();i++){
					if(value.equals(parameters.get(i))){
						found++;
					}
				}
				if(found == (parameters.size())){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.size()){
					if(value.equals(parameters.get(i))){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	public static boolean contem(Double value, Double[] parameters, boolean containsAll){
		boolean ret = false;
		if(parameters != null && parameters.length > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.length;i++){
					if(value.equals(parameters[i])){
						found++;
					}
				}
				if(found == (parameters.length)){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.length){
					if(value.equals(parameters[i])){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	public static boolean contem(Float value, List<Float> parameters, boolean containsAll){
		boolean ret = false;
		if(parameters != null && parameters.size() > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.size();i++){
					if(value.equals(parameters.get(i))){
						found++;
					}
				}
				if(found == (parameters.size())){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.size()){
					if(value.equals(parameters.get(i))){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	public static boolean contem(Float value, Float[] parameters, boolean containsAll){
		boolean ret = false;
		if(parameters != null && parameters.length > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.length;i++){
					if(value.equals(parameters[i])){
						found++;
					}
				}
				if(found == (parameters.length)){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.length){
					if(value.equals(parameters[i])){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}

	public static boolean contem(Long value, List<Long> parameters, boolean containsAll) {
		boolean ret = false;
		if(parameters != null && parameters.size() > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.size();i++){
					if(value.equals(parameters.get(i))){
						found++;
					}
				}
				if(found == (parameters.size())){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.size()){
					if(value.equals(parameters.get(i))){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	
	public static boolean contem(long value, long[] parameters, boolean containsAll){
		boolean ret = false;
		if(parameters != null && parameters.length > 0){
			if(containsAll){
				int found = 0;
				for(int i = 0; i < parameters.length;i++){
					if(value == parameters[i]){
						found++;
					}
				}
				if(found == (parameters.length)){
					ret = true;
				}
			}else{
				int i = 0;
				boolean founded = false;
				while(!founded && i < parameters.length){
					if(value == parameters[i]){
						ret = true;
						founded = true;
					}
					i++;
				}
			}
		}
		return ret;
	}
	public static boolean naoNulloEMaiorQueZero(Long numero){
		boolean ret = false;
		if(numero != null && numero > 0){
			ret = true;
		}
		return ret;
	}

	public static boolean naoNulloEMaiorQueZero(Double numero){
		boolean ret = false;
		if(numero != null && numero > 0){
			ret = true;
		}
		return ret;
	}

	public static boolean naoNulloEMaiorQueZero(Float numero){
		boolean ret = false;
		if(numero != null && numero > 0){
			ret = true;
		}
		return ret;
	}

	public static boolean naoNulloEMaiorQueZero(Integer numero){
		boolean ret = false;
		if(numero != null && numero > 0){
			ret = true;
		}
		return ret;
	}
	
	public static boolean eNumero(Object numero){
		boolean ret = false;
		
		long[] numeros = new long[]{0L,1L,2L,3L,4L,5L,6L,7L,8L,9L};
		
		for(Character caracter : numero.toString().toCharArray()){
			if(contem(Long.parseLong(caracter.toString()), numeros, false)){
				ret = true;
			}
		}
		return ret;
	}
	
}