package util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class GenericUtil {

	public String toString() {
        String ret = "Class: " + this.getClass().getName() + " - n� do objeto: " + this.hashCode() + "[ \n";
        for (Field field : this.getClass().getDeclaredFields()) {
			try {
					if(ret.length() < 400){
						if(!Modifier.isFinal(field.getModifiers())){
							if(field.isAccessible()){
								ret += field.getName() + " = " + verifyFieldIsDate(getValueFromField(field)) + "\n";	
							}else{
								field.setAccessible(true);
								ret += field.getName() + " = " + verifyFieldIsDate(getValueFromField(field)) + "\n";
								field.setAccessible(false);
							}
						}else{
							ret += field.getName() + "\n";
						}	        		
					}
			}catch (Exception e) {
				e.printStackTrace();
			}
        }
        ret += "]";

        return ret;
	 }

	private String getValueFromField(Field field){
		String ret = "";
		try {
			if(Collection.class.isAssignableFrom(field.getType())){
				ret = "list = " + field.getName();
			}else{
				if(field.get(this) != null && field.get(this).toString() != null){
					ret = field.get(this).toString();
				}else{
					ret = "null";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}
	
	private String verifyFieldIsDate(String value){
		String ret = value;
		String aux = "";
		if(value.contains("GregorianCalendar")){
			aux = value.substring(value.indexOf("time=") + 5, value.indexOf(","));
			ret = DateUtil.millisToDateString(Long.parseLong(aux),"dd/MM/yyyy");
		}
		return ret;
	}

	public static boolean set(Object objeto, String nomeCampo, Object valorCampo) {
	    boolean ret = false;
		Class<?> classe = objeto.getClass();
	    if (classe != null) {
	        try {
	            Field field = classe.getDeclaredField(nomeCampo);
	            field.setAccessible(true);
	            field.set(objeto, valorCampo);
	            ret = true;
	        } catch (Exception e) {
	            ret = false;
	        }
	    }
	    return ret;
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T get(Object objeto, String nomeCampo) {
	    Class<?> classe = objeto.getClass();
	    if (classe != null) {
	        try {
	            Field field = classe.getDeclaredField(nomeCampo);
	            field.setAccessible(true);
	            return (T) field.get(objeto);
	        } catch (Exception e) {
	            return null;
	        }
	    }
	    return null;
	}
	
	public static boolean verificaObjetoInteiroNulo(Object objeto) {
		boolean ret = false;
	    Class<?> classe = objeto.getClass();
	    try {
		    if (classe != null) {
	        	Field[] fields = classe.getDeclaredFields();
	        	int i = 0;
	        	for(Field field : fields){
	        		field.setAccessible(true);
					if(field.get(objeto) == null){
						i++;
					}
	        	}
	
	        	if(i == (fields.length - 1)){
	        		ret = true;
	        	}
		    }
	    } catch (IllegalArgumentException e) {
	    	ret = true;
	    } catch (IllegalAccessException e) {
	    	ret = true;
	    }
	    return ret;
	}
	
	public static boolean notNulleIgual(Object validation, String text){
		boolean ret = false;
		if(text != null && validation != null && validation.equals(text))
			ret = true;
		return ret;
	}
	
	@SuppressWarnings("rawtypes")
	public static boolean notNulleMaiorQueZero(Collection collection){
		boolean ret = false;
		if(collection != null && collection.size() > 0)
			ret = true;
		return ret;
	}
	
	public static boolean notNulleMaiorQueZero(byte[] array){
		boolean ret = false;
		if(array != null && array.length > 0)
			ret = true;
		return ret;
	}
	
	@SuppressWarnings("rawtypes")
	public static boolean notNulleMaiorQueZero(Map map){
		boolean ret = false;
		if(map != null && map.size() > 0)
			ret = true;
		return ret;
	}
	
	public static boolean notNulleMaiorQueZero(Object[] array){
		boolean ret = false;
		if(array != null && array.length > 0)
			ret = true;
		return ret;
	}
	
	@SuppressWarnings({"rawtypes","unchecked"})
	public static List<List> criaSubLista(Collection collection, int indiceQuebra){
		List<List> ret = new ArrayList<List>();
		
		int sublistas = (collection.size() / indiceQuebra) + 1;
		int listasCriadas  = 0;
		int indiceInicial = 0;
		int indiceFinal = indiceQuebra;
		
		while(listasCriadas < sublistas){
			if(indiceFinal >= collection.size()){
				indiceFinal = collection.size();
			}
			List listaAux = ((List<List>) collection).subList(indiceInicial, indiceFinal);
			indiceInicial = indiceFinal;
			indiceFinal = indiceFinal + indiceQuebra;
			ret.add(listaAux);
			listasCriadas++;
		}
		return ret;
	}
	
	public static Object transfereDadosDiferentesEntreObjetos(Object reciever, Object sender) {
	    Class<?> classeReciever = reciever.getClass();
	    
	    try {
	    	
	    	if (classeReciever != null) {
	    		
	        	Field[] atributos = classeReciever.getDeclaredFields();
	        	
	        	for(Field atributo : atributos){
	        		atributo.setAccessible(true);
	        		
	        		try{
						if(!Modifier.isFinal(atributo.getModifiers())){
							
		        			if(atributo.get(reciever) instanceof String){
		        				if(!atributo.get(reciever).equals(atributo.get(sender))){
		        					atributo.set(reciever, atributo.get(sender));
		        				}
		        			}else {
		    					if(atributo.get(reciever) != atributo.get(sender)){
		    						atributo.set(reciever, atributo.get(sender));
	    						}
	    					}
		        			
	        			}
	        		}catch (Exception e) {}
	        		
	        	}
		    }
	    } catch (IllegalArgumentException e) {
	    } 
	    	
	    return reciever;
	}
	
	@SuppressWarnings("unchecked")
	public static Object transfereDadosDiferentesEntreObjetos(Object reciever, Object sender, String[] exceptions) {
	    Class<?> classeReciever = reciever.getClass();
	    
	    try {
	    	
	    	if (classeReciever != null) {
	    		
				List<Field> atributos = GenericUtil.arrayToList(classeReciever.getDeclaredFields());
				
				if(GenericUtil.notNulleMaiorQueZero(exceptions)){
					for(int i = 0; i < atributos.size(); i++){
						for(String ex : exceptions){
							if(atributos.get(i).getName().equals(ex)){
								atributos.remove(i);
							}
						}
					}
				}
	        	
	        	for(Field atributo : atributos){
	        		atributo.setAccessible(true);
	        		
	        		try{
						if(!Modifier.isFinal(atributo.getModifiers())){
							
		        			if(atributo.get(reciever) instanceof String){
		        				if(!atributo.get(reciever).equals(atributo.get(sender))){
		        					atributo.set(reciever, atributo.get(sender));
		        				}
		        			}else {
		    					if(atributo.get(reciever) != atributo.get(sender)){
		    						atributo.set(reciever, atributo.get(sender));
	    						}
	    					}
		        			
	        			}
	        		}catch (Exception e) {}
	        		
	        	}
		    }
	    } catch (IllegalArgumentException e) {
	    } 

	    return reciever;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List arrayToList(Object[] array){
		List ret = null;
		if(array != null && array.length > 0){
			ret = new ArrayList();
			for(Object o : array){
				ret.add(o);
			}
		}
		return ret;
	}
		
}