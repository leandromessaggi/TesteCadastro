package services;

public class CadService {

}
