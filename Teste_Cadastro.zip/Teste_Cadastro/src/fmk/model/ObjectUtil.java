package fmk.model;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collection;

import util.DateUtil;

public class ObjectUtil {

	public String toString() {
        StringBuilder ret = new StringBuilder();
        
        ret.append("Class: " + this.getClass().getName() + " - n� do objeto: " + this.hashCode() + "[ \n");
        for (Field field : this.getClass().getDeclaredFields()) {
			try {
					if(ret.length() < 400){
						if(!Modifier.isFinal(field.getModifiers())){
							if(field.isAccessible()){
								ret.append(field.getName() + " = " + verifyFieldIsDate(getValueFromField(field)) + "\n");	
							}else{
								field.setAccessible(true);
								ret.append(field.getName() + " = " + verifyFieldIsDate(getValueFromField(field)) + "\n");
								field.setAccessible(false);
							}
						}else{
							ret.append(field.getName() + "\n");
						}	        		
					}
			}catch (Exception e) {
				e.printStackTrace();
			}
        }
        ret.append("]");

//        System.out.println(ret.toString());
        
        return ret.toString();
	 }

	private String getValueFromField(Field field){
		String ret = "";
		try {
			if(Collection.class.isAssignableFrom(field.getType())){
				ret = "list = " + field.getName();
			}else{
				if(field.get(this) != null && field.get(this).toString() != null){
					ret = field.get(this).toString();
				}else{
					ret = "null";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}
	
	private String verifyFieldIsDate(String value){
		String ret = value;
		String aux = "";
		if(value.contains("GregorianCalendar")){
			aux = value.substring(value.indexOf("time=") + 5, value.indexOf(","));
			ret = DateUtil.millisToDateString(Long.parseLong(aux),"dd/MM/yyyy");
		}
		return ret;
	}
	
}